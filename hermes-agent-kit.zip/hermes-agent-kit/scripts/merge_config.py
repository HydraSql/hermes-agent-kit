#!/usr/bin/env python3
"""Gabungkan config-overrides.yaml ke ~/.hermes/config.yaml.

- Dict digabung secara mendalam (nilai override menang).
- List digabung tanpa duplikat (isi lama tetap ada).
- config.yaml lama dibackup sebelum ditulis ulang.

Pemakaian: merge_config.py <config.yaml> <overrides.yaml>
"""
import shutil
import sys
import time
from pathlib import Path

import yaml


def merge(base, override):
    if isinstance(base, dict) and isinstance(override, dict):
        out = dict(base)
        for key, value in override.items():
            out[key] = merge(base[key], value) if key in base else value
        return out
    if isinstance(base, list) and isinstance(override, list):
        out = list(base)
        for item in override:
            if item not in out:
                out.append(item)
        return out
    return override


def main():
    if len(sys.argv) != 3:
        sys.exit("Pemakaian: merge_config.py <config.yaml> <overrides.yaml>")
    config_path = Path(sys.argv[1])
    override_path = Path(sys.argv[2])

    override = yaml.safe_load(override_path.read_text()) or {}
    base = {}
    if config_path.exists():
        base = yaml.safe_load(config_path.read_text()) or {}
        backup = config_path.with_name(
            f"{config_path.name}.bak-{time.strftime('%Y%m%d-%H%M%S')}"
        )
        shutil.copy2(config_path, backup)
        print(f"Backup config lama: {backup}")

    if not isinstance(base, dict):
        sys.exit(f"{config_path} bukan YAML berbentuk mapping; dibatalkan.")

    merged = merge(base, override)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(
        yaml.safe_dump(merged, sort_keys=False, allow_unicode=True)
    )
    print(f"Konfigurasi keamanan diterapkan ke {config_path}")


if __name__ == "__main__":
    main()
