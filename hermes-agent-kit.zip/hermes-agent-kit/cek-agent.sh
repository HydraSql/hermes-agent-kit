#!/usr/bin/env bash
# Cek kesehatan agent. Jalankan: sudo bash cek-agent.sh
set -uo pipefail

AGENT_USER="${AGENT_USER:-hermes}"
[[ $EUID -eq 0 ]] || { echo "Jalankan sebagai root: sudo bash cek-agent.sh"; exit 1; }
id "$AGENT_USER" >/dev/null 2>&1 || { echo "User '$AGENT_USER' belum ada. Jalankan install-agent.sh dulu."; exit 1; }

uid="$(id -u "$AGENT_USER")"
HERMES_DIR="/home/$AGENT_USER/.hermes"
ok()   { printf '  \e[32m[OK]\e[0m  %s\n' "$*"; }
bad()  { printf '  \e[31m[!!]\e[0m  %s\n' "$*"; FAILED=1; }
FAILED=0

as_agent() {
  sudo -u "$AGENT_USER" -H XDG_RUNTIME_DIR="/run/user/$uid" \
    DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" \
    PATH="/home/$AGENT_USER/.local/bin:/home/$AGENT_USER/.npm-global/bin:/usr/local/bin:/usr/bin:/bin" \
    bash -lc "$1"
}

echo "Cek agent Hermes (user: $AGENT_USER)"

v="$(as_agent 'hermes --version' 2>/dev/null | head -n1)"
[[ -n $v ]] && ok "Hermes terpasang: $v" || bad "Perintah hermes tidak ditemukan"

if [[ -f $HERMES_DIR/.env ]]; then
  perm="$(stat -c %a "$HERMES_DIR/.env")"
  [[ $perm == 600 ]] && ok ".env aman (izin 600)" || bad ".env izinnya $perm, perbaiki: chmod 600 $HERMES_DIR/.env"
  ids="$(sed -n 's/^TELEGRAM_ALLOWED_USERS=//p' "$HERMES_DIR/.env" | tail -n1)"
  [[ -n $ids ]] && ok "Akses Telegram dikunci untuk ID: $ids" || bad "TELEGRAM_ALLOWED_USERS kosong - SIAPA PUN bisa akses bot!"
  grep -q '^TELEGRAM_BOT_TOKEN=.\+' "$HERMES_DIR/.env" && ok "Token bot tersimpan" || bad "Token bot belum diisi"
else
  bad "File $HERMES_DIR/.env tidak ada"
fi

if grep -q 'unauthorized_dm_behavior: ignore' "$HERMES_DIR/config.yaml" 2>/dev/null; then
  ok "Orang asing diabaikan (unauthorized_dm_behavior: ignore)"
else
  bad "unauthorized_dm_behavior belum 'ignore'"
fi
grep -q 'mode: manual' "$HERMES_DIR/config.yaml" 2>/dev/null \
  && ok "Perintah berbahaya wajib persetujuan Anda (approvals: manual)" \
  || bad "Mode approval bukan manual"

[[ -f $HERMES_DIR/SOUL.md ]] && ok "Identitas agent (SOUL.md) terpasang" || bad "SOUL.md tidak ada"
n_skills="$(find "$HERMES_DIR/skills" -name SKILL.md 2>/dev/null | wc -l)"
ok "Jumlah skill terpasang: $n_skills"

if as_agent 'hermes chat -q "Balas hanya dengan kata: siap"' </dev/null >/dev/null 2>&1; then
  ok "Model AI merespons"
else
  bad "Model AI tidak merespons (cek API key/saldo: sudo agentctl model)"
fi

as_agent 'systemctl --user is-active hermes-gateway' >/dev/null 2>&1 \
  && ok "Layanan Telegram berjalan" || bad "Layanan Telegram tidak berjalan (sudo agentctl gateway restart)"
as_agent 'systemctl --user is-enabled hermes-gateway' >/dev/null 2>&1 \
  && ok "Layanan otomatis menyala saat restart" || bad "Layanan belum enabled"
[[ "$(loginctl show-user "$AGENT_USER" -p Linger --value 2>/dev/null)" == yes ]] \
  && ok "Linger aktif (tetap jalan walau SSH ditutup)" || bad "Linger belum aktif (loginctl enable-linger $AGENT_USER)"

command -v ufw >/dev/null && ufw status | grep -q 'Status: active' \
  && ok "Firewall aktif" || echo "  [--]  Firewall tidak aktif (opsional)"
systemctl is-active fail2ban >/dev/null 2>&1 && ok "fail2ban aktif" || echo "  [--]  fail2ban tidak aktif (opsional)"

echo
if (( FAILED )); then
  echo "Ada masalah di atas. Log 50 baris terakhir:"
  as_agent 'journalctl --user -u hermes-gateway -n 50 --no-pager' 2>/dev/null || true
  exit 1
fi
echo "Semua beres. Kirim pesan ke bot Anda untuk uji akhir."
