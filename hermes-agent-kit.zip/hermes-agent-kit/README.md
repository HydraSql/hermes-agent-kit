# Hermes Agent Kit: Agent AI Pribadi di Telegram

Panduan dan installer otomatis untuk menjalankan **agent AI pribadi 24 jam** di VPS, yang Anda ajak chat lewat **Telegram**. Agent dibangun di atas [Hermes Agent](https://github.com/NousResearch/hermes-agent) (open-source, MIT) buatan Nous Research, dengan pengaturan keamanan yang sudah dikunci: **hanya akun Telegram Anda yang bisa memakainya**.

```
HP (Telegram)  ->  Bot Telegram  ->  Hermes Agent (VPS)  ->  API model AI (misalnya DeepSeek)
      ^                                                                  |
      +------------------------------ balasan ---------------------------+
```

> Diuji dengan Hermes Agent v0.22.5 di VPS Ubuntu. Menu dan pertanyaan Hermes bisa sedikit berbeda di versi lain.

## Daftar isi

1. [Fitur](#fitur)
2. [Yang perlu disiapkan](#yang-perlu-disiapkan)
3. [Biaya](#biaya)
4. [Langkah 1: Siapkan bot Telegram dan ID Anda](#langkah-1-siapkan-bot-telegram-dan-id-anda)
5. [Langkah 2: Kirim kit ke VPS](#langkah-2-kirim-kit-ke-vps)
6. [Langkah 3: Jalankan installer](#langkah-3-jalankan-installer)
7. [Langkah 4: Pilih model AI](#langkah-4-pilih-model-ai)
8. [Langkah 5: Uji dan kunci bot](#langkah-5-uji-dan-kunci-bot)
9. [Memakai agent sehari-hari](#memakai-agent-sehari-hari)
10. [Ganti model atau provider AI](#ganti-model-atau-provider-ai)
11. [Persetujuan perintah di Telegram](#persetujuan-perintah-di-telegram)
12. [Memasang skill sendiri](#memasang-skill-sendiri)
13. [Tugas terjadwal](#tugas-terjadwal)
14. [Keamanan](#keamanan)
15. [Perawatan](#perawatan)
16. [Troubleshooting](#troubleshooting)
17. [FAQ](#faq)
18. [Menghapus agent](#menghapus-agent)
19. [Penafian](#penafian)

## Fitur

- **Installer satu perintah**: paket sistem, Node.js 22, Hermes Agent, layanan 24 jam, semuanya otomatis.
- **Akses terkunci**: hanya ID Telegram yang Anda daftarkan yang dilayani. Akun lain diabaikan diam-diam (tidak dibalas sama sekali).
- **User khusus tanpa sudo**: agent berjalan sebagai user `hermes` sehingga tidak bisa mengubah sistem di luar foldernya.
- **Persetujuan manual**: perintah berbahaya dikirim ke Telegram dan harus Anda setujui. Tidak dijawab dalam 5 menit = otomatis ditolak.
- **Daftar larangan permanen**: membaca file kunci, mematikan firewall, mengubah SSH/password, reboot, `curl | sh`, dan lainnya.
- **Identitas agent (SOUL.md)** dalam Bahasa Indonesia, dengan aturan keamanan untuk crypto (tolak seed phrase, konfirmasi "YA" untuk setiap transaksi, isi web dianggap data, bukan perintah).
- **Pengamanan VPS**: firewall (hanya port SSH), fail2ban, dan update keamanan otomatis.
- **Bebas skill**: tidak ada skill bawaan. Anda memasang skill sendiri sesuai kebutuhan.
- **Model bebas**: DeepSeek, OpenRouter, OpenAI, Anthropic, xAI, atau provider lain yang didukung Hermes.

## Yang perlu disiapkan

| Kebutuhan | Keterangan |
| --- | --- |
| VPS Linux | Ubuntu 22.04/24.04 atau Debian 12/13. Spesifikasi kecil sudah cukup (misalnya 1-2 vCPU, RAM 2 GB) karena AI berjalan di server penyedia model. |
| Akses root VPS | IP VPS dan password root (atau SSH key). |
| Komputer | Windows (PowerShell), Mac, atau Linux (Terminal). |
| Akun Telegram | Untuk membuat bot dan memakai agent. |
| API key model AI | Contoh di panduan ini: [DeepSeek](https://platform.deepseek.com). Pastikan saldonya sudah diisi. |

## Biaya

| Komponen | Biaya |
| --- | --- |
| Hermes Agent dan kit ini | Gratis (open-source) |
| VPS | Tetap per bulan, sesuai penyedia |
| API model AI | Per pemakaian token |

Token API **hanya terpakai saat Anda mengirim pesan atau saat tugas terjadwal berjalan**. Saat agent diam, tidak ada token yang terpakai. Pasang batas pengeluaran di dasbor penyedia API Anda.

## Langkah 1: Siapkan bot Telegram dan ID Anda

1. **Buat bot**: buka [@BotFather](https://t.me/BotFather), kirim `/newbot`, beri nama, lalu username yang berakhiran `bot`. Simpan token yang diberikan (bentuknya `123456789:AA...`).
2. **Ambil ID numerik Anda**: kirim pesan apa saja ke [@userinfobot](https://t.me/userinfobot). Catat angka **Id** yang muncul.
   - Yang dipakai adalah **angka**, bukan @username.
   - Jangan memakai angka di depan token bot. Itu ID bot, bukan ID Anda.

> Token bot sama berharganya dengan password. Jangan dibagikan, jangan di-screenshot. Kalau bocor, kirim `/revoke` ke @BotFather untuk membuat token baru.

## Langkah 2: Kirim kit ke VPS

Pilih salah satu cara.

### Cara A: clone langsung di VPS (paling mudah)

Masuk ke VPS (lihat bagian [masuk ke VPS](#masuk-ke-vps)), lalu:

```bash
apt-get update && apt-get install -y git
git clone https://github.com/USERNAME/hermes-agent-kit.git
cd hermes-agent-kit
```

Ganti `USERNAME` dengan username GitHub pemilik repo ini.

### Cara B: upload file zip dari komputer

Unduh repo ini sebagai zip (tombol **Code -> Download ZIP** di GitHub), lalu upload ke VPS.

**Windows (PowerShell):**
```powershell
scp "C:\Users\NAMA_ANDA\Downloads\hermes-agent-kit.zip" root@IP_VPS_ANDA:/root/
```

**Mac/Linux (Terminal):**
```bash
scp ~/Downloads/hermes-agent-kit.zip root@IP_VPS_ANDA:/root/
```

Lalu di VPS:
```bash
apt-get update && apt-get install -y unzip
unzip hermes-agent-kit.zip
cd hermes-agent-kit*
```

> Zip dari GitHub biasanya bernama `hermes-agent-kit-main.zip` dan foldernya `hermes-agent-kit-main`. Sesuaikan nama file di perintah di atas.

### Masuk ke VPS

**Windows:** buka PowerShell (Start -> ketik `PowerShell` -> Enter). **Mac/Linux:** buka Terminal.

```bash
ssh root@IP_VPS_ANDA
```

- Pertama kali terhubung akan muncul `Are you sure you want to continue connecting (yes/no)?`. Ketik `yes`, Enter.
- Saat mengetik password, karakternya **memang tidak terlihat**. Ketik saja lalu Enter.
- Di PowerShell, **klik kanan = paste**.
- Berhasil masuk jika tampilan berubah menjadi seperti `root@namaserver:~#`.

### Jika muncul "REMOTE HOST IDENTIFICATION HAS CHANGED"

Ini terjadi jika VPS pernah di-reinstall dengan IP yang sama, sehingga sidik jari servernya berubah.

1. **Pastikan dulu ini memang VPS Anda.** Kalau Anda tidak pernah reinstall, buka console/VNC dari panel penyedia VPS dan jalankan:
   ```bash
   ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub
   ```
   Cocokkan hasil `SHA256:...` dengan yang tertulis di pesan peringatan. Kalau berbeda, **jangan login** dan hubungi penyedia VPS.
2. Hapus kunci lama di komputer Anda:
   ```bash
   ssh-keygen -R IP_VPS_ANDA
   ```
3. Kalau perintah itu menjawab `not found`, hapus baris secara manual. Pesan peringatan menyebut nomor barisnya, contoh `Offending ECDSA key in ...known_hosts:27`.
   - **Windows:** `notepad "$env:USERPROFILE\.ssh\known_hosts"`, tekan Ctrl+G, ketik nomor baris, hapus baris itu, simpan.
   - **Mac/Linux:** `sed -i.bak '27d' ~/.ssh/known_hosts` (ganti `27` dengan nomor barisnya).
4. Ulangi perintah `ssh` atau `scp`, lalu jawab `yes`.

## Langkah 3: Jalankan installer

Dari dalam folder kit di VPS:

```bash
sudo bash install-agent.sh
```

Installer bekerja dalam 7 tahap. Berikut yang akan Anda lihat dan cara menjawabnya.

| Tahap | Yang terjadi | Yang perlu Anda lakukan |
| --- | --- | --- |
| 1/7 Data Telegram | Diminta token bot dan ID Telegram | Tempel token (tidak terlihat saat ditempel, itu normal), lalu ketik ID numerik Anda |
| | `Aktifkan firewall?` | Ketik `Y` |
| 2/7 Paket sistem | Memasang paket, Node.js 22, firewall, fail2ban | Tunggu. Pesan `WARNING: apt does not have a stable CLI interface` itu normal |
| 3/7 Hermes Agent | Membuat user `hermes`, mengunduh dan memasang Hermes | Tunggu 5-15 menit. Tahap `Installing Python` memang lama dan layar tidak bergerak |
| | Wizard Hermes muncul (lihat di bawah) | Tekan **ESC** |
| | `Start the gateway now...?` | Ketik `Y` |
| | `Start the gateway automatically on login/boot with systemd?` | Ketik `Y` |
| 4/7 Kunci akses | Menulis token dan ID ke `.env`, menerapkan aturan keamanan | Tidak perlu apa-apa |
| 5/7 Identitas | Memasang `SOUL.md`, folder skill kosong, dan perintah `agentctl` | Tidak perlu apa-apa |
| 6/7 Model AI | `Atur model AI sekarang?` | Ketik `Y`, lalu ikuti [Langkah 4](#langkah-4-pilih-model-ai) |
| 7/7 Layanan 24 jam | Menyalakan agent sebagai layanan systemd | Jika ditanya soal systemd/start, ketik `Y` |

### Wizard bawaan Hermes

Di tengah tahap 3, installer resmi Hermes bisa menampilkan:

```
How would you like to set up Hermes?
  (●) Quick Setup (Nous Portal)
  (○) Full setup
  (○) Blank Slate
```

**Tekan ESC** untuk melewatinya. Model AI akan diatur di tahap 6, sedangkan Telegram sudah diatur oleh installer kit ini.

- Jangan tekan **Ctrl+C**, karena itu menghentikan seluruh installer.
- Jangan pilih **Quick Setup (Nous Portal)** kalau Anda ingin memakai DeepSeek.
- Kalau ESC tidak berfungsi, pilih **Full setup**, pilih provider Anda, lalu **lewati (skip)** bagian messaging/Telegram dan fitur opsional lainnya.

Installer aman dijalankan ulang kapan saja. File lama (`config.yaml`, `SOUL.md`) dibackup otomatis.

## Langkah 4: Pilih model AI

Di tahap 6 (atau kapan saja lewat `sudo agentctl model`), muncul menu pemilihan provider.

1. **Tunggu sampai menu tampil penuh** sebelum menekan tombol. Kalau panah ditekan terlalu cepat, muncul karakter aneh seperti `^[OB` dan pilihan bisa salah.
2. Pakai **panah atas/bawah** sampai tanda pilihan berada di **DeepSeek**, lalu **Enter**. Tekan `/` untuk mencari.
   - Kalau DeepSeek tidak ada di daftar, pilih **Custom endpoint** dengan base URL `https://api.deepseek.com/v1`.
3. Tempel **API key** (klik kanan di PowerShell), lalu Enter.
4. Pilih model. Menu Hermes v0.22.5 menampilkan beberapa nama, tetapi **API DeepSeek saat ini hanya menerima dua**:

   | Model | Kapan dipakai |
   | --- | --- |
   | `deepseek-flash` | **Disarankan untuk awal.** Versi Flash terbaru: cepat, murah, cocok untuk agent 24 jam |
   | `deepseek-v4-pro` | Tugas rumit dan analisis mendalam. Lebih lambat dan lebih mahal |

   Nama lain di menu (misalnya `deepseek-v4-flash`, `deepseek-v4-flash-vision-exp`, atau nama yang diketik sendiri seperti `deepseek-v4.1-flash`) akan ditolak dengan error `HTTP 400: The supported API model names are ...`. Daftar nama yang diterima bisa berubah; error tersebut selalu menyebutkan nama yang valid.

5. Pilih **tingkat berpikir (reasoning effort)**:

   | Pilihan | Keterangan |
   | --- | --- |
   | `medium` | **Disarankan.** Seimbang antara kecepatan, kualitas, dan biaya |
   | `high` | Lebih teliti, lebih lambat, lebih banyak token |
   | `ultra` | Paling dalam, paling lambat dan paling mahal |

6. Installer menguji model secara otomatis. Berhasil jika muncul `Model AI merespons dengan baik.`

**Kalau salah pilih** (misalnya muncul `Active provider: none` atau `Hermes is not connected to any AI provider yet`), selesaikan dulu installernya, lalu jalankan:

```bash
sudo agentctl model
sudo agentctl chat -q "Balas satu baris: model berfungsi"
sudo agentctl gateway restart
```

> Kecepatan agent paling ditentukan oleh **model dan tingkat berpikir** yang dipilih, bukan oleh spesifikasi VPS.

## Langkah 5: Uji dan kunci bot

1. **Cek kesehatan** di VPS:
   ```bash
   sudo bash ~/hermes-agent-kit/cek-agent.sh
   ```
   Semua baris idealnya **[OK]** hijau. Baris **[!!]** merah menunjukkan masalah dan menampilkan log.
2. **Uji dari Telegram**: kirim `halo, perkenalkan dirimu` ke bot Anda. Agent seharusnya menjawab dalam Bahasa Indonesia.
3. **Kunci dari grup**: di @BotFather kirim `/setjoingroups`, pilih bot Anda, pilih **Disable**.
4. **Uji keamanan**: minta akun Telegram lain mengirim pesan ke bot. Bot seharusnya **tidak membalas sama sekali**.

Selesai. Agent Anda sudah berjalan 24 jam.

## Memakai agent sehari-hari

Perintah dasar di Telegram:

| Perintah | Fungsi |
| --- | --- |
| `/new` atau `/reset` | Mulai percakapan baru. Lebih cepat dan hemat token |
| `/model` | Lihat atau ganti model |

Contoh permintaan:

- `Riset project <nama> dan beri tahu risikonya.`
- `Rangkum berita teknologi terbaru hari ini, sertakan link sumbernya.`
- `Setiap hari jam 7 pagi kirimi saya ringkasan pasar crypto.`
- `Kabari saya kalau BNB turun di bawah <harga>.`
- `Ingat: saya hanya tertarik project di BNB Chain dan Base.`
- `Buatkan script Python untuk ... dan simpan di folder kerjamu.`

Tips: beri perintah yang spesifik (apa, kapan, format hasilnya). Mulai dari tugas kecil, lalu tambah sedikit demi sedikit.

## Ganti model atau provider AI

**Model dari provider yang sudah tersimpan**: langsung dari Telegram.

```
/model
/model deepseek:deepseek-v4-pro
```

**Provider baru** (OpenRouter, OpenAI, Anthropic, xAI, dll.): diatur sekali di VPS. API key sengaja tidak dimasukkan lewat chat supaya tidak tersimpan di riwayat Telegram.

```bash
sudo agentctl model           # pilih provider baru, tempel API key, pilih model
sudo agentctl gateway restart
```

Setelah tersimpan, Anda bisa berpindah antar provider langsung dari Telegram dengan `/model`. Kalau setelah ganti model bot terasa aneh, kirim `/new`.

> **OpenRouter** praktis kalau ingin mencoba banyak model: satu API key untuk ratusan model.

## Persetujuan perintah di Telegram

Saat agent ingin menjalankan perintah yang ditandai berbahaya, bot mengirim pesan **"Hermes wants to run a command that needs your OK"** beserta isi perintah dan alasannya.

| Tombol | Artinya | Kapan dipakai |
| --- | --- | --- |
| **Allow Once** | Izinkan sekali ini saja | **Pilihan default** untuk perintah yang Anda pahami dan aman |
| **Session** | Izinkan pola ini sampai percakapan berakhir | Agent perlu menjalankan perintah serupa berulang kali dalam satu tugas |
| **Always** | Izinkan pola ini selamanya | **Hindari.** Perintah sejenis tidak akan ditanyakan lagi |
| **Deny** | Tolak | Ragu, tidak paham, atau perintah terlihat mencurigakan |

Tidak dijawab dalam 5 menit = otomatis ditolak. Perintah di [daftar larangan permanen](config/config-overrides.yaml) tetap diblokir meski Anda menyetujuinya.

Pola yang pernah Anda izinkan dengan **Always** bisa dilihat dan dihapus di bagian `command_allowlist` dengan:

```bash
sudo agentctl edit config
```

## Memasang skill sendiri

Kit ini **tidak memasang skill apa pun**. Skill adalah folder berisi file `SKILL.md` (instruksi) dan kadang script pendukung:

```
/home/hermes/.hermes/skills/<nama-skill>/SKILL.md
```

**Memasang dari repositori GitHub:**

```bash
sudo -u hermes -H bash -c 'git clone --depth 1 <URL_REPO> /tmp/skill-src && cp -r /tmp/skill-src/<folder-skill> ~/.hermes/skills/ && rm -rf /tmp/skill-src'
sudo agentctl gateway restart
```

**Membuat skill sendiri:** buat folder dan file `SKILL.md`:

```bash
sudo -u hermes mkdir -p /home/hermes/.hermes/skills/nama-skill
sudo -u hermes nano /home/hermes/.hermes/skills/nama-skill/SKILL.md
```

Isi minimal `SKILL.md`:

```markdown
---
name: nama-skill
description: Kapan skill ini dipakai, dalam satu kalimat.
---

# Judul skill

Langkah-langkah yang harus diikuti agent.
```

Kalau skill memakai `npx`/npm, Node.js 22 sudah terpasang dan npm global diarahkan ke folder user `hermes` (tidak butuh root). Anda juga bisa meminta agent membuatkan skill dari tugas yang sering diulang, lalu memeriksa isinya.

### Tips keamanan skill

- Pasang skill **hanya dari sumber resmi**. Marketplace skill agent pernah dipenuhi ratusan skill palsu, terutama yang menyamar sebagai bot trading/wallet crypto, yang mencuri password, SSH key, dan private key.
- **Baca isi `SKILL.md` dan script-nya** sebelum dipasang. Waspadai skill yang menyuruh mengunduh file zip, menjalankan `curl ... | sh`, atau meminta seed phrase.
- Untuk skill wallet (misalnya Binance Agentic Wallet dari repositori resmi `binance/binance-skills-hub`): atur **batas harian kecil** dan **konfirmasi wajib di aplikasi**. Aturan konfirmasi "YA" di `SOUL.md` tetap berlaku untuk semua skill.

## Tugas terjadwal

Agent bisa menjalankan tugas otomatis (cron) dan mengirim hasilnya ke Telegram. Cukup minta lewat chat, misalnya:

```
Buat tugas terjadwal bernama "ringkasan-pagi" setiap hari jam 07.00 WIB.
Isinya: ringkasan berita crypto terpenting, maksimal 10 baris, dengan link sumber.
Jika tidak ada yang penting, jangan kirim apa pun.
Tunjukkan rencananya dulu sebelum membuat jadwal.
```

Hal yang perlu diingat:

- **Setiap kali tugas berjalan, token API terpakai.** Interval 30 menit = 48 kali per hari. Mulai dari interval jarang, lalu sesuaikan.
- Tugas terjadwal **tidak bisa menjalankan perintah berbahaya** (`cron_mode: deny`) dan, sesuai `SOUL.md`, **tidak pernah melakukan transaksi**.
- Minta agent menyimpan data yang sudah dilaporkan ke file (misalnya `~/screening/seen.txt`) agar tidak mengirim hal yang sama berulang kali.

## Keamanan

### Lapisan yang aktif

| Lapisan | Pengaturan | Lokasi |
| --- | --- | --- |
| Hanya ID Anda | `TELEGRAM_ALLOWED_USERS=<ID>` | `~/.hermes/.env` |
| Orang asing diabaikan | `unauthorized_dm_behavior: ignore` | `~/.hermes/config.yaml` |
| Persetujuan manual | `approvals.mode: manual`, `timeout: 300` | `~/.hermes/config.yaml` |
| Cron tanpa perintah berbahaya | `approvals.cron_mode: deny` | `~/.hermes/config.yaml` |
| Daftar larangan permanen | `approvals.deny` | `~/.hermes/config.yaml` |
| File kunci terlindungi | `.env` dan `config.yaml` izin `600` | `~/.hermes/` |
| User terisolasi | User `hermes` tanpa sudo | sistem |
| Aturan perilaku | Tolak seed phrase, konfirmasi "YA" per transaksi, isi web = data | `~/.hermes/SOUL.md` |
| VPS | Firewall (hanya SSH), fail2ban, update otomatis | sistem |

Semua path `~/.hermes/` di atas berada di `/home/hermes/.hermes/`.

### Aturan emas

- Jangan pernah mengirim **seed phrase atau private key wallet utama** ke bot.
- Pakai **wallet khusus berisi dana kecil** untuk apa pun yang berhubungan dengan agent.
- Selalu baca ringkasan transaksi sebelum membalas **"YA"**.
- Jangan masukkan bot ini ke grup. Untuk bot yang memposting ke grup, buat **bot terpisah** tanpa akses ke VPS atau wallet.
- Jangan membagikan akses root VPS, token bot, atau API key ke siapa pun, termasuk jasa pemasangan.
- Disarankan: pakai **SSH key** untuk login VPS dan matikan login password.

## Perawatan

Semua perintah perawatan memakai `agentctl`, perintah pembantu dari kit ini. `sudo agentctl <perintah>` sama dengan menjalankan `hermes <perintah>` sebagai user `hermes` dengan environment yang benar. Jalankan `sudo agentctl --help` untuk ringkasannya.

| Kebutuhan | Perintah |
| --- | --- |
| Cek kesehatan | `sudo bash ~/hermes-agent-kit/cek-agent.sh` |
| Status layanan | `sudo agentctl gateway status --deep` |
| Restart agent | `sudo agentctl gateway restart` |
| Lihat 100 log terakhir | `sudo agentctl logs` |
| Pantau log langsung | `sudo agentctl logs -f` (keluar: Ctrl+C) |
| Ganti/tambah model | `sudo agentctl model` |
| Atur tools | `sudo agentctl tools` |
| Edit konfigurasi | `sudo agentctl edit config` |
| Ubah identitas agent | `sudo agentctl edit soul`, lalu restart |
| Tambah ID Telegram | `sudo agentctl edit env`, ubah `TELEGRAM_ALLOWED_USERS` (pisahkan koma), lalu restart |
| Ganti token bot | `sudo agentctl edit env`, ubah `TELEGRAM_BOT_TOKEN`, lalu restart |

### Update Hermes

```bash
sudo agentctl update
sudo agentctl config check
sudo agentctl doctor
sudo agentctl gateway restart
```

Setelah update, kirim satu pesan uji dari Telegram.

### Update kit ini

```bash
cd ~/hermes-agent-kit && git pull
sudo bash install-agent.sh
```

Kalau hanya ingin memasang `agentctl` versi terbaru tanpa menjalankan ulang installer:

```bash
sudo install -m 755 ~/hermes-agent-kit/agentctl /usr/local/bin/agentctl
```

Installer aman diulang: konfigurasi lama dibackup dan aturan keamanan digabung tanpa menghapus pengaturan model Anda.

### Lokasi file di VPS

```
/home/hermes/.hermes/
├── .env            # token bot, ID Telegram, API key (izin 600)
├── config.yaml     # pengaturan Hermes + aturan keamanan
├── SOUL.md         # identitas dan aturan agent
├── skills/         # skill Anda (awalnya kosong)
├── memories/       # memori agent
└── cron/           # data tugas terjadwal
```

## Troubleshooting

Mulai selalu dengan `sudo bash ~/hermes-agent-kit/cek-agent.sh`, lalu cari gejalanya di tabel ini.

| Gejala | Penyebab umum | Solusi |
| --- | --- | --- |
| `REMOTE HOST IDENTIFICATION HAS CHANGED` | VPS pernah di-reinstall | Lihat [bagian ini](#jika-muncul-remote-host-identification-has-changed) |
| Installer lama di `Installing Python` | Mengunduh dependensi di VPS kecil | Tunggu hingga 15 menit. Cek dengan `top` di jendela SSH kedua. Lebih dari 20 menit tanpa perubahan: Ctrl+C lalu jalankan ulang installer |
| `Format token tidak valid` | Token tidak lengkap | Salin ulang token dari @BotFather |
| `Harus berupa angka` | Yang dimasukkan @username | Pakai ID numerik dari @userinfobot |
| `Active provider: none` / `not connected to any AI provider` | Provider belum dipilih | `sudo agentctl model`, pilih provider, lalu restart |
| Bot menjawab `HTTP 400: The supported API model names are ...` | Nama model tidak didukung provider | Di Telegram: `/model deepseek:deepseek-flash`, lalu `/new` |
| `Model belum merespons` | API key salah atau saldo habis | Cek saldo di dasbor provider, ulangi `hermes model` |
| Bot tidak membalas sama sekali | Layanan mati atau ID salah | `hermes gateway status --deep`; pastikan ID di `.env` adalah ID numerik Anda |
| Log berisi `conflict` / `getUpdates` | Dua proses memakai token yang sama | Matikan proses lain (misalnya `hermes gateway run` di jendela lain) |
| Bot mati setelah SSH ditutup | Layanan atau linger belum aktif | `sudo loginctl enable-linger hermes`, lalu `sudo agentctl gateway install --start-now` |
| Bot lambat | Model besar atau tingkat berpikir tinggi | Pakai model Flash dan `medium`, kirim `/new` |
| Error setelah update | Format konfigurasi berubah | `hermes config check`, `hermes config migrate`, `hermes doctor` |
| `hermes: command not found` atau `Failed to connect to bus` | Perintah dijalankan sebagai root atau tanpa environment user | Selalu jalankan lewat `sudo agentctl ...` |

Saat meminta bantuan, sertakan isi log tetapi **hapus dulu token, API key, dan ID** dari teksnya.

## FAQ

**Apakah agent memakai token saat tidak dipakai?**
Tidak. Token terpakai hanya saat Anda mengirim pesan atau saat tugas terjadwal berjalan.

**Apakah spesifikasi VPS memengaruhi kecepatan?**
Hampir tidak. Kecepatan ditentukan oleh model, tingkat berpikir, dan jumlah langkah/tool yang dijalankan agent. Spesifikasi VPS baru berpengaruh jika Anda menjalankan browser otomatis atau model lokal.

**Bisakah API key dimasukkan lewat Telegram?**
Bisa secara teknis, tapi tidak disarankan karena kuncinya akan tersimpan di riwayat chat. Masukkan lewat `hermes model` di VPS.

**Bisakah orang lain memakai bot saya?**
Tidak, kecuali ID Telegram-nya Anda tambahkan ke `TELEGRAM_ALLOWED_USERS`. Ingat bahwa siapa pun yang diizinkan mendapat akses penuh ke agent, termasuk terminal VPS.

**Bisakah agent mencari di X (Twitter)?**
Tidak secara bawaan. Hermes punya tool `x_search` yang membutuhkan kredensial xAI (langganan SuperGrok lewat `hermes auth add xai-oauth`, atau `XAI_API_KEY` di `.env`). Model utama tetap bisa DeepSeek.

**Bisakah agent bertransaksi crypto?**
Bisa jika Anda memasang skill wallet. Agent tetap wajib meminta konfirmasi "YA" untuk setiap transaksi. Sebagai contoh, skill resmi Binance Agentic Wallet saat ini mendukung transfer, swap, dan limit order, tetapi belum mendukung mint NFT. Cek dokumentasi resminya untuk pembaruan.

**Hermes atau OpenClaw?**
Kit ini memakai Hermes karena dirancang untuk berjalan 24 jam di VPS dengan Telegram, punya sistem persetujuan perintah, dan bisa membuat skill sendiri tanpa bergantung pada marketplace terbuka.

## Menghapus agent

```bash
sudo agentctl gateway stop
sudo agentctl gateway uninstall || true
sudo loginctl disable-linger hermes
sudo userdel -r hermes
sudo rm -f /usr/local/bin/agentctl
```

Perintah terakhir menghapus user `hermes` beserta seluruh isi `/home/hermes`, termasuk konfigurasi, memori, dan skill. Cabut juga token bot lewat `/revoke` di @BotFather dan hapus API key di dasbor provider.

## Isi repo

| File | Fungsi |
| --- | --- |
| `install-agent.sh` | Installer otomatis |
| `cek-agent.sh` | Cek kesehatan dan keamanan agent |
| `agentctl` | Perintah pembantu, dipasang ke `/usr/local/bin/agentctl` |
| `config/SOUL.md` | Identitas, gaya bicara, dan aturan keamanan agent |
| `config/config-overrides.yaml` | Kunci akses Telegram, persetujuan, dan daftar larangan |
| `scripts/merge_config.py` | Menggabungkan aturan keamanan ke `config.yaml` Hermes tanpa menimpa pengaturan lain |

## Penafian

- Proyek ini tidak berafiliasi dengan Nous Research, Telegram, DeepSeek, Binance, atau penyedia lain yang disebut.
- Agent AI bisa salah. Periksa hasil penting, terutama yang menyangkut uang.
- Bukan nasihat keuangan. Segala risiko pemakaian, termasuk transaksi crypto, menjadi tanggung jawab pengguna.

## Lisensi

[MIT](LICENSE)
