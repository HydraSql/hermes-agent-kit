#!/usr/bin/env bash
# =====================================================================
#  Installer Agent AI Pribadi (Hermes Agent + Telegram)
#  Untuk VPS Ubuntu 22.04/24.04 atau Debian 12/13.
#
#  Jalankan SEBAGAI ROOT dari dalam folder kit ini:
#     sudo bash install-agent.sh
#
#  Yang dilakukan:
#   1. Minta token bot + ID Telegram Anda (hanya ID ini yang bisa akses)
#   2. Pasang paket sistem, Node.js 22, firewall, fail2ban, update otomatis
#   3. Buat user khusus "hermes" (tanpa sudo) dan pasang Hermes Agent
#   4. Pasang identitas agent (SOUL.md) dan aturan keamanan
#   5. Atur model AI, lalu jalankan agent 24 jam sebagai layanan
#   (Tanpa skill bawaan - pasang skill Anda sendiri setelah agent jalan.)
# =====================================================================
set -euo pipefail

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_USER="${AGENT_USER:-hermes}"
HERMES_INSTALL_URL="https://hermes-agent.nousresearch.com/install.sh"

c_green=$'\e[32m'; c_yellow=$'\e[33m'; c_red=$'\e[31m'; c_bold=$'\e[1m'; c_off=$'\e[0m'
step() { printf '\n%s==> %s%s\n' "$c_bold$c_green" "$*" "$c_off"; }
info() { printf '    %s\n' "$*"; }
warn() { printf '%s[!] %s%s\n' "$c_yellow" "$*" "$c_off"; }
die()  { printf '%s[x] %s%s\n' "$c_red" "$*" "$c_off" >&2; exit 1; }

ask_yes_no() { # ask_yes_no "pertanyaan" default(y/n)
  local prompt="$1" def="${2:-y}" ans
  local hint="[Y/n]"; [[ $def == n ]] && hint="[y/N]"
  read -rp "    $prompt $hint " ans || true
  ans="${ans:-$def}"
  [[ ${ans,,} == y* ]]
}

as_agent() { # jalankan perintah sebagai user agent, dengan systemd user aktif
  local uid; uid="$(id -u "$AGENT_USER")"
  sudo -u "$AGENT_USER" -H \
    XDG_RUNTIME_DIR="/run/user/$uid" \
    DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" \
    PATH="/home/$AGENT_USER/.local/bin:/home/$AGENT_USER/.npm-global/bin:/usr/local/bin:/usr/bin:/bin" \
    bash -lc "$1"
}

# ---------------------------------------------------------------------
[[ $EUID -eq 0 ]] || die "Jalankan sebagai root: sudo bash install-agent.sh"
[[ -f /etc/os-release ]] || die "Sistem operasi tidak dikenali."
# shellcheck disable=SC1091
. /etc/os-release
case "${ID:-}" in
  ubuntu|debian) ;;
  *) warn "Diuji untuk Ubuntu/Debian, terdeteksi: ${PRETTY_NAME:-?}"
     ask_yes_no "Tetap lanjut?" n || exit 1 ;;
esac
for f in config/config-overrides.yaml config/SOUL.md scripts/merge_config.py agentctl; do
  [[ -f "$KIT_DIR/$f" ]] || die "File kit hilang: $f (ekstrak ulang zip-nya)."
done

cat <<EOF

${c_bold}Installer Agent AI Pribadi${c_off}
Agent hanya akan merespons akun Telegram yang Anda daftarkan.
Siapkan: token bot dari @BotFather dan ID numerik Telegram Anda (@userinfobot).
EOF

# --- 1. Data Telegram --------------------------------------------------
step "1/7  Data Telegram"
while :; do
  read -rsp "    Token bot Telegram (input disembunyikan): " BOT_TOKEN; echo
  BOT_TOKEN="${BOT_TOKEN//[[:space:]]/}"
  [[ $BOT_TOKEN =~ ^[0-9]{6,}:[A-Za-z0-9_-]{30,}$ ]] && break
  warn "Format token tidak valid. Contoh: 123456789:AAH... (dari @BotFather)"
done

BOT_NAME=""
if command -v curl >/dev/null 2>&1; then
  if resp="$(curl -fsS --max-time 15 "https://api.telegram.org/bot${BOT_TOKEN}/getMe" 2>/dev/null)"; then
    BOT_NAME="$(printf '%s' "$resp" | sed -n 's/.*"username":"\([^"]*\)".*/\1/p')"
    info "Token valid. Bot: @${BOT_NAME:-?}"
  else
    warn "Token tidak bisa diverifikasi ke Telegram (salah token atau jaringan)."
    ask_yes_no "Tetap lanjut dengan token ini?" n || exit 1
  fi
fi

while :; do
  read -rp "    ID numerik Telegram Anda (pisahkan koma jika lebih dari satu): " ALLOWED_IDS
  ALLOWED_IDS="${ALLOWED_IDS//[[:space:]]/}"
  if [[ $ALLOWED_IDS =~ ^[0-9]{5,}(,[0-9]{5,})*$ ]]; then
    bot_prefix="${BOT_TOKEN%%:*}"
    if [[ ",$ALLOWED_IDS," == *",$bot_prefix,"* ]]; then
      warn "Itu ID bot, bukan ID akun Anda. Ambil ID Anda dari @userinfobot."
      continue
    fi
    break
  fi
  warn "Harus berupa angka (contoh: 123456789), bukan @username."
done
info "Akses dibatasi untuk ID: $ALLOWED_IDS"

SETUP_FIREWALL=false
ask_yes_no "Aktifkan firewall (hanya port SSH yang dibuka)?" y && SETUP_FIREWALL=true

# --- 2. Paket sistem ---------------------------------------------------
step "2/7  Memasang paket sistem"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq curl git ca-certificates python3 python3-yaml unzip \
  ufw fail2ban unattended-upgrades >/dev/null
info "Paket dasar terpasang."

node_major=0
command -v node >/dev/null 2>&1 && node_major="$(node -v | sed 's/^v\([0-9]*\).*/\1/')"
if (( node_major < 22 )); then
  info "Memasang Node.js 22 (dibutuhkan banyak skill, misalnya skill Binance)..."
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null
  apt-get install -y -qq nodejs >/dev/null
fi
info "Node.js $(node -v)"

systemctl enable --now fail2ban >/dev/null 2>&1 || warn "fail2ban gagal diaktifkan."
dpkg-reconfigure -f noninteractive unattended-upgrades >/dev/null 2>&1 || true

if $SETUP_FIREWALL; then
  ssh_ports="$(sshd -T 2>/dev/null | awk '/^port /{print $2}' | sort -u)"
  [[ -n $ssh_ports ]] || ssh_ports=22
  for p in $ssh_ports; do ufw allow "${p}/tcp" >/dev/null; info "Firewall: port SSH $p dibuka"; done
  ufw default deny incoming >/dev/null
  ufw default allow outgoing >/dev/null
  ufw --force enable >/dev/null
  info "Firewall aktif. (Telegram tidak butuh port masuk.)"
fi

# --- 3. User khusus + Hermes ------------------------------------------
step "3/7  Membuat user '$AGENT_USER' dan memasang Hermes Agent"
if ! id "$AGENT_USER" >/dev/null 2>&1; then
  useradd -m -s /bin/bash "$AGENT_USER"
  info "User '$AGENT_USER' dibuat (tanpa akses sudo, demi keamanan)."
else
  info "User '$AGENT_USER' sudah ada, dipakai ulang."
fi
AGENT_HOME="/home/$AGENT_USER"
HERMES_DIR="$AGENT_HOME/.hermes"
loginctl enable-linger "$AGENT_USER"
for _ in $(seq 1 20); do [[ -S /run/user/$(id -u "$AGENT_USER")/bus ]] && break; sleep 0.5; done

as_agent 'mkdir -p ~/.npm-global && npm config set prefix ~/.npm-global >/dev/null
  grep -q "npm-global/bin" ~/.bashrc || echo "export PATH=\"\$HOME/.npm-global/bin:\$HOME/.local/bin:\$PATH\"" >> ~/.bashrc'

if as_agent 'command -v hermes' >/dev/null 2>&1; then
  info "Hermes sudah terpasang, memperbarui..."
  as_agent 'hermes update' || warn "Update gagal, lanjut dengan versi terpasang."
else
  info "Mengunduh installer resmi Hermes..."
  info "Jika wizard Hermes muncul: boleh pilih DeepSeek, LEWATI bagian messaging/Telegram."
  tmp_installer="$(mktemp)"
  curl -fsSL "$HERMES_INSTALL_URL" -o "$tmp_installer"
  chmod 644 "$tmp_installer"
  as_agent "bash '$tmp_installer'" </dev/tty || warn "Installer Hermes keluar dengan kode non-nol, dicek di langkah berikut."
  rm -f "$tmp_installer"
fi
as_agent 'hermes --version' >/dev/null 2>&1 || die "Perintah 'hermes' tidak ditemukan setelah instalasi."
info "$(as_agent 'hermes --version' 2>/dev/null | head -n1)"

# --- 4. Telegram + aturan akses ---------------------------------------
step "4/7  Mengunci akses Telegram dan menerapkan aturan keamanan"
install -d -m 700 -o "$AGENT_USER" -g "$AGENT_USER" "$HERMES_DIR"
ENV_FILE="$HERMES_DIR/.env"
touch "$ENV_FILE"
# hapus nilai lama, lalu tulis yang baru
sed -i '/^TELEGRAM_BOT_TOKEN=/d;/^TELEGRAM_ALLOWED_USERS=/d' "$ENV_FILE"
{
  printf 'TELEGRAM_BOT_TOKEN=%s\n' "$BOT_TOKEN"
  printf 'TELEGRAM_ALLOWED_USERS=%s\n' "$ALLOWED_IDS"
} >> "$ENV_FILE"
chown "$AGENT_USER:$AGENT_USER" "$ENV_FILE"
chmod 600 "$ENV_FILE"
unset BOT_TOKEN
info ".env ditulis (izin 600, hanya bisa dibaca user '$AGENT_USER')."

python3 "$KIT_DIR/scripts/merge_config.py" "$HERMES_DIR/config.yaml" "$KIT_DIR/config/config-overrides.yaml"
chown "$AGENT_USER:$AGENT_USER" "$HERMES_DIR"/config.yaml*
chmod 600 "$HERMES_DIR/config.yaml"

# --- 5. Identitas agent ------------------------------------------------
step "5/7  Memasang identitas agent"
if [[ -f $HERMES_DIR/SOUL.md ]]; then
  cp -a "$HERMES_DIR/SOUL.md" "$HERMES_DIR/SOUL.md.bak-$(date +%Y%m%d-%H%M%S)"
  info "SOUL.md lama dibackup."
fi
install -m 644 -o "$AGENT_USER" -g "$AGENT_USER" "$KIT_DIR/config/SOUL.md" "$HERMES_DIR/SOUL.md"
install -d -o "$AGENT_USER" -g "$AGENT_USER" "$HERMES_DIR/skills"
info "SOUL.md terpasang. Folder skill kosong siap diisi: $HERMES_DIR/skills"
install -m 755 "$KIT_DIR/agentctl" /usr/local/bin/agentctl
info "Perintah pembantu terpasang: sudo agentctl <perintah hermes>"

# --- 6. Model AI -------------------------------------------------------
step "6/7  Mengatur model AI"
cat <<EOF
    Pilih provider dan masukkan API key di menu berikut (contoh: DeepSeek).
    API key dimasukkan di sini, BUKAN lewat chat Telegram, supaya tidak
    tersimpan di riwayat chat. Setelah itu, model bisa diganti dari
    Telegram dengan perintah /model.
EOF
if ask_yes_no "Atur model AI sekarang?" y; then
  as_agent 'hermes model' </dev/tty || warn "Pengaturan model belum selesai. Ulangi: sudo agentctl model"
  if as_agent 'hermes chat -q "Balas satu baris: model berfungsi"' </dev/null; then
    info "Model AI merespons dengan baik."
  else
    warn "Model belum merespons. Cek API key/saldo, lalu: sudo agentctl model"
  fi
else
  warn "Model belum diatur. Jalankan nanti: sudo agentctl model"
fi

# --- 7. Layanan 24 jam -------------------------------------------------
step "7/7  Menjalankan agent sebagai layanan 24 jam"
as_agent 'hermes gateway stop' >/dev/null 2>&1 || true
if as_agent 'hermes gateway install --start-now'; then
  sleep 3
  as_agent 'systemctl --user is-enabled hermes-gateway' >/dev/null 2>&1 \
    && info "Layanan aktif dan otomatis menyala saat VPS restart." \
    || warn "Layanan terpasang tapi belum enabled. Cek: sudo bash cek-agent.sh"
else
  warn "Gagal memasang layanan. Coba manual: sudo agentctl gateway install --start-now"
fi

cat <<EOF

${c_bold}${c_green}Selesai!${c_off}
  1. Buka Telegram, kirim pesan ke ${BOT_NAME:+@$BOT_NAME }: "halo, perkenalkan dirimu"
  2. Akun lain yang mencoba chat akan diabaikan diam-diam.
  3. Cek kesehatan agent kapan saja:   sudo bash $KIT_DIR/cek-agent.sh
     Lihat log:                        sudo agentctl logs
  4. Ganti model dari Telegram:        /model
     Tambah provider/API key baru:     sudo agentctl model
  5. Pasang skill sendiri ke folder:   $HERMES_DIR/skills/<nama-skill>/SKILL.md
     lalu restart:                     sudo agentctl gateway restart

Langkah keamanan tambahan (di @BotFather):
  /setjoingroups -> pilih bot Anda -> Disable   (bot tidak bisa dimasukkan ke grup)
EOF
